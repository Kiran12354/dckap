-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 24, 2021 at 06:35 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dckap`
--

-- --------------------------------------------------------

--
-- Table structure for table `filter`
--

CREATE TABLE IF NOT EXISTS `filter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `filter`
--

INSERT INTO `filter` (`id`, `price`) VALUES
(1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `seller_name` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `product_name` varchar(225) DEFAULT NULL,
  `price` varchar(225) DEFAULT NULL,
  `brand` varchar(225) DEFAULT NULL,
  `type` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `seller_name`, `address`, `phone`, `product_name`, `price`, `brand`, `type`) VALUES
(1, 'kiran kumar N', 'Banglore', '9743608536', 'smart phone', '15000', 'Samsung', 'New'),
(2, 'vishwanath', 'Ranenennur', '9743608536', 'Laptop', '35000', 'lenevo', 'New'),
(3, 'vinay', 'Raichur', '9986938048', 'Laptop', '19000', 'lenevo', 'Used');
